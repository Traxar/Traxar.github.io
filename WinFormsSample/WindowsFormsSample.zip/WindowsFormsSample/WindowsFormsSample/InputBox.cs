﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsSample {
    /// <summary>
    /// Usercontrol for labeled textbox inputs.
    /// </summary>
    public partial class InputBox : UserControl {
        [Description("InputLabel"), Category("Data")]
        [Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]//needed if override
        public override string Text { get => label.Text; set => label.Text = value; }
        [Description("InputValue"), Category("Data")]
        public string Input { get => textBox.Text; set => textBox.Text = value; }
        public InputBox() {
            InitializeComponent();
        }
    }
}
