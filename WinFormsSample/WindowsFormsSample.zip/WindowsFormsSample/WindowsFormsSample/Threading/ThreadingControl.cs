﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsSample.Threading {
    public partial class ThreadingControl : UserControl {
        ThreadingSample threadingSample;

        delegate void ProgressCallback(int count, string output, bool done);

        private int tasks;
        private int workload;
        private int stagger;
        private int workers;
        private bool multiThreading;

        public ThreadingControl() {
            InitializeComponent();
            int processorCount = Environment.ProcessorCount;
            inputBoxWorkers.Input = processorCount.ToString();
            inputBoxTasks.Input = (2 * processorCount + 1).ToString();
        }

        private bool ParseInputs() {
            try {
                tasks = int.Parse(inputBoxTasks.Input);
                workload = int.Parse(inputBoxWorkload.Input);
                stagger = int.Parse(inputBoxStagger.Input);
                workers = int.Parse(inputBoxWorkers.Input);
                multiThreading = checkBoxThreading.Checked;
            }
            catch {
                MessageBox.Show("Error parsing Inputs");
                return false;
            }
            return true;
        }

        private void buttonRun_Click(object sender, EventArgs e) {
            progressBar.Value = 0;
            textBoxOutput.Text = "";
            if (ParseInputs()) {
                progressBar.Maximum = tasks;
                threadingSample = new ThreadingSample() {
                    Tasks = tasks,
                    Workload = workload,
                    Stagger = stagger,
                    Workers = workers
                };
                threadingSample.callback = updateProgress;
                if (multiThreading)
                    Task.Run(() => threadingSample.RunMulti());
                else
                    threadingSample.RunSingle();
            }
        }


        private void updateProgress(int count, string output, bool done) {
            if (progressBar.InvokeRequired) {
                ProgressCallback p = new ProgressCallback(updateProgress);
                Invoke(p, new object[] { count , output, done});
            }
            else {
                if (done) 
                    textBoxOutput.AppendText(output);
                progressBar.Value = count;
                progressBar.Refresh();
            }
        }

    }
}
