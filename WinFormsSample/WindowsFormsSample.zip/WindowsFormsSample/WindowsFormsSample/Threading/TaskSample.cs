﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WindowsFormsSample.Threading {

    class DataSample {
        public int input;
        public int? output = null;

        public DataSample() {

        }

        public DataSample Clone(){
            return MemberwiseClone() as DataSample;
        }

    }

    class TaskSample {

        private int workload;
        private static object locker = null;

        public TaskSample(int workload) {
            this.workload = workload;
        }

        public void Run(DataSample data) {
            Thread.Sleep(workload);
            data.output = data.input;
        }
    }
}
