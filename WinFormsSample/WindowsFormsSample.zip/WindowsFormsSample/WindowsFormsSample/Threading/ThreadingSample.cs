﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WindowsFormsSample.Threading {
    class ThreadingSample {
        private object locker = new object();

        public delegate void Callback(int count, string output, bool done);
        public Callback callback = new Callback((count, output, done) => { return; });
        private DateTime lastCallback = DateTime.Now;
        private TimeSpan timeSpanCallback = new TimeSpan(1000);

        private int count;

        private int tasks;
        private int workload;
        private int stagger;
        private int workers;

        string output;

        public int Tasks { get => tasks; set => tasks = value; }
        public int Workload { get => workload; set => workload = value; }
        public int Stagger { get => stagger; set => stagger = value; }
        public int Workers { get => workers; set => workers = value; }

        public string Output { get => output; set => output = value; }

        public ThreadingSample() {

        }

        public void Run() {
            count = 0;
            output = "";
            DateTime timeStart = DateTime.Now;
            callback(count,"",false);
            DataSample data = new DataSample();
            using (SemaphoreSlim concurrencySemaphore = new SemaphoreSlim(workers)) {
                List<Task> taskList = new List<Task>();
                for (int i = 0; i < tasks; i++) {
                    concurrencySemaphore.Wait();
                    data.input = i;
                    DataSample dataClone = data.Clone();
                    var t = Task.Run(() =>
                    {
                        DoThread(dataClone);
                        concurrencySemaphore.Release();
                    });
                    taskList.Add(t);
                    Thread.Sleep(stagger);
                }
                Task.WaitAll(taskList.ToArray());
            }
            callback(count, output += "Done! Total time: " + (DateTime.Now - timeStart).ToString(@"mm\:ss\.fff"), true);
        }

        private void DoThread(DataSample data) {
            lock (locker) {
                output += "Task " + data.input + " started.\r\n";
            }
            if (data.output != null) throw new AccessViolationException("output of data wasn't null!");
            TaskSample task = new TaskSample(workload);
            task.Run(data);
            if (data.output != data.input) throw new AccessViolationException("output of data wasn't correct!");
            lock (locker) {
                output += "    Task " + data.input + " ended.\r\n";
                count++;
                if (DateTime.Now - lastCallback > timeSpanCallback) {
                    callback(count,"",false);
                    lastCallback = DateTime.Now;
                }
            }
        }



    }
}
