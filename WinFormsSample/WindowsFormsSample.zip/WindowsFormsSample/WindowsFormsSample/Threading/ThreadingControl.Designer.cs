﻿
namespace WindowsFormsSample.Threading {
    partial class ThreadingControl {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.inputBoxWorkers = new WindowsFormsSample.InputBox();
            this.inputBoxStagger = new WindowsFormsSample.InputBox();
            this.inputBoxWorkload = new WindowsFormsSample.InputBox();
            this.inputBoxTasks = new WindowsFormsSample.InputBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.buttonRun = new System.Windows.Forms.Button();
            this.textBoxOutput = new System.Windows.Forms.TextBox();
            this.checkBoxThreading = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.AutoScroll = true;
            this.splitContainer.Panel1.Controls.Add(this.checkBoxThreading);
            this.splitContainer.Panel1.Controls.Add(this.inputBoxWorkers);
            this.splitContainer.Panel1.Controls.Add(this.inputBoxStagger);
            this.splitContainer.Panel1.Controls.Add(this.inputBoxWorkload);
            this.splitContainer.Panel1.Controls.Add(this.inputBoxTasks);
            this.splitContainer.Panel1.Controls.Add(this.progressBar);
            this.splitContainer.Panel1.Controls.Add(this.buttonRun);
            this.splitContainer.Panel1MinSize = 100;
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.textBoxOutput);
            this.splitContainer.Size = new System.Drawing.Size(409, 412);
            this.splitContainer.SplitterDistance = 100;
            this.splitContainer.TabIndex = 0;
            // 
            // inputBoxWorkers
            // 
            this.inputBoxWorkers.AutoSize = true;
            this.inputBoxWorkers.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.inputBoxWorkers.Dock = System.Windows.Forms.DockStyle.Top;
            this.inputBoxWorkers.Input = "";
            this.inputBoxWorkers.Location = new System.Drawing.Point(0, 153);
            this.inputBoxWorkers.MinimumSize = new System.Drawing.Size(40, 40);
            this.inputBoxWorkers.Name = "inputBoxWorkers";
            this.inputBoxWorkers.Size = new System.Drawing.Size(100, 40);
            this.inputBoxWorkers.TabIndex = 5;
            this.inputBoxWorkers.Text = "Workers:";
            // 
            // inputBoxStagger
            // 
            this.inputBoxStagger.AutoSize = true;
            this.inputBoxStagger.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.inputBoxStagger.Dock = System.Windows.Forms.DockStyle.Top;
            this.inputBoxStagger.Input = "0";
            this.inputBoxStagger.Location = new System.Drawing.Point(0, 113);
            this.inputBoxStagger.MinimumSize = new System.Drawing.Size(40, 40);
            this.inputBoxStagger.Name = "inputBoxStagger";
            this.inputBoxStagger.Size = new System.Drawing.Size(100, 40);
            this.inputBoxStagger.TabIndex = 4;
            this.inputBoxStagger.Text = "Staggering: [ms]";
            // 
            // inputBoxWorkload
            // 
            this.inputBoxWorkload.AutoSize = true;
            this.inputBoxWorkload.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.inputBoxWorkload.Dock = System.Windows.Forms.DockStyle.Top;
            this.inputBoxWorkload.Input = "1";
            this.inputBoxWorkload.Location = new System.Drawing.Point(0, 73);
            this.inputBoxWorkload.MinimumSize = new System.Drawing.Size(40, 40);
            this.inputBoxWorkload.Name = "inputBoxWorkload";
            this.inputBoxWorkload.Size = new System.Drawing.Size(100, 40);
            this.inputBoxWorkload.TabIndex = 3;
            this.inputBoxWorkload.Text = "Workload: [ms]";
            // 
            // inputBoxTasks
            // 
            this.inputBoxTasks.AutoSize = true;
            this.inputBoxTasks.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.inputBoxTasks.Dock = System.Windows.Forms.DockStyle.Top;
            this.inputBoxTasks.Input = "";
            this.inputBoxTasks.Location = new System.Drawing.Point(0, 33);
            this.inputBoxTasks.MinimumSize = new System.Drawing.Size(40, 40);
            this.inputBoxTasks.Name = "inputBoxTasks";
            this.inputBoxTasks.Size = new System.Drawing.Size(100, 40);
            this.inputBoxTasks.TabIndex = 2;
            this.inputBoxTasks.Text = "Tasks:";
            // 
            // progressBar
            // 
            this.progressBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.progressBar.Location = new System.Drawing.Point(0, 23);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(100, 10);
            this.progressBar.TabIndex = 6;
            // 
            // buttonRun
            // 
            this.buttonRun.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonRun.Location = new System.Drawing.Point(0, 0);
            this.buttonRun.Name = "buttonRun";
            this.buttonRun.Size = new System.Drawing.Size(100, 23);
            this.buttonRun.TabIndex = 1;
            this.buttonRun.Text = "Run";
            this.buttonRun.UseVisualStyleBackColor = true;
            this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
            // 
            // textBoxOutput
            // 
            this.textBoxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxOutput.Location = new System.Drawing.Point(0, 0);
            this.textBoxOutput.Multiline = true;
            this.textBoxOutput.Name = "textBoxOutput";
            this.textBoxOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxOutput.Size = new System.Drawing.Size(305, 412);
            this.textBoxOutput.TabIndex = 0;
            // 
            // checkBoxThreading
            // 
            this.checkBoxThreading.AutoSize = true;
            this.checkBoxThreading.Checked = true;
            this.checkBoxThreading.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxThreading.Dock = System.Windows.Forms.DockStyle.Top;
            this.checkBoxThreading.Location = new System.Drawing.Point(0, 193);
            this.checkBoxThreading.Name = "checkBoxThreading";
            this.checkBoxThreading.Size = new System.Drawing.Size(100, 17);
            this.checkBoxThreading.TabIndex = 7;
            this.checkBoxThreading.Text = "Multithreading";
            this.checkBoxThreading.UseVisualStyleBackColor = true;
            // 
            // ThreadingControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer);
            this.Name = "ThreadingControl";
            this.Size = new System.Drawing.Size(409, 412);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Button buttonRun;
        private System.Windows.Forms.TextBox textBoxOutput;
        private InputBox inputControl1;
        private InputBox inputBoxTasks;
        private InputBox inputBoxWorkload;
        private InputBox inputBoxStagger;
        private InputBox inputBoxWorkers;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.CheckBox checkBoxThreading;
    }
}
