﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsSample.Charting {
    public partial class ChartingControl : UserControl {

        private Func<double, double> function;
        private ChartSample chartSample;

        public ChartingControl() {
            InitializeComponent();
            chartSample = new ChartSample(chart);
        }

        private bool ParseInputs() {
            try {
                function = ChartSample.StringToFunc(inputBoxFunction.Input).func;
            }
            catch {
                MessageBox.Show("Error parsing Inputs");
                return false;
            }
            return true;
        }

        private void buttonClear_Click(object sender, EventArgs e) {
            chart.Series.Clear();
        }

        private void buttonAdd_Click(object sender, EventArgs e) {
            if (ParseInputs()) {
                chartSample.AddFunction(function);
            }
        }
    }
}
