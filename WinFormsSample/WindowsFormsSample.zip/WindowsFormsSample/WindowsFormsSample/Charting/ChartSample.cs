﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsSample.Charting {
    class ChartSample {
        Chart chart;
        int f = 0;
        int precision = 200;

        public ChartSample(Chart chart) {
            this.chart = chart;
            ChartArea ca = chart.ChartAreas[0];
            Axis xa = ca.AxisX;
            Axis ya = ca.AxisY;
            xa.Minimum = -5;
            xa.Maximum = 5;
            xa.Interval = 5;
            xa.MajorGrid.LineColor = Color.FromArgb(63, 0, 0, 0);
            xa.MinorGrid.Enabled = true;
            xa.MinorGrid.LineColor = Color.FromArgb(31, 0, 0, 0);

            ya.Minimum = -5;
            ya.Maximum = 5;
            ya.Interval = 5;
            ya.MajorGrid.LineColor = Color.FromArgb(63, 0, 0, 0);
            ya.MinorGrid.Enabled = true;
            ya.MinorGrid.LineColor = Color.FromArgb(31, 0, 0, 0);
        }

        public void AddFunction(Func<double,double> func) {
            ChartArea ca = chart.ChartAreas[0];
            Axis xa = ca.AxisX;
            Axis ya = ca.AxisY;
            Series s = chart.Series.Add("f"+(f++));
            s.ChartType = SeriesChartType.FastLine;
            s.IsVisibleInLegend = false;

            for (int i = 0; i <= precision; i++) {
                double x = (xa.Minimum * (precision - i) + xa.Maximum * i) / precision;
                double y = func(x);
                if (Double.IsNaN(y)) continue;
                s.Points.AddXY(x, Math.Max(Math.Min(y,2*ya.Maximum),2*ya.Minimum));
            }
        }


        public static (Func<double, double> func, string unread) StringToFunc(string s) {
            s = s.Trim();
            if (s.Length == 0) {
                return (delegate (double x) {
                    return 0;
                }, "");
            }
            int i = s.IndexOf(' ');
            string f, r;
            if (i == -1) {
                f = s;
                r = "";
            }
            else {
                f = s.Substring(0, i);
                r = s.Substring(i + 1);
            }
            try {
                double value = Double.Parse(f);
                return (delegate (double x) {
                    return value;
                }, r);
            }
            catch (Exception) {
                switch (f) {
                    case "x":
                        return (delegate (double x) {
                            return x;
                        }, r);
                    case "pi":
                        return (delegate (double x) {
                            return Math.PI;
                        }, r);
                    case "e":
                        return (delegate (double x) {
                            return Math.E;
                        }, r);
                    case "sin":
                        var p1 = StringToFunc(r);
                        return (delegate (double x) {
                            return Math.Sin(p1.func(x));
                        }, p1.unread);
                    case "cos":
                        p1 = StringToFunc(r);
                        return (delegate (double x) {
                            return Math.Cos(p1.func(x));
                        }, p1.unread);
                    case "log":
                        p1 = StringToFunc(r);
                        return (delegate (double x) {
                            return Math.Log(p1.func(x));
                        }, p1.unread);
                    case "exp":
                        p1 = StringToFunc(r);
                        return (delegate (double x) {
                            return Math.Exp(p1.func(x));
                        }, p1.unread);
                    case "stp":
                        p1 = StringToFunc(r);
                        return (delegate (double x) {
                            return p1.func(x) < 0 ? 0 : 1;
                        }, p1.unread);
                    case "+":
                        p1 = StringToFunc(r);
                        var p2 = StringToFunc(p1.unread);
                        return (delegate (double x) {
                            return p1.func(x) + p2.func(x);
                        }, p2.unread);
                    case "-":
                        p1 = StringToFunc(r);
                        p2 = StringToFunc(p1.unread);
                        return (delegate (double x) {
                            return p1.func(x) - p2.func(x);
                        }, p2.unread);
                    case "*":
                        p1 = StringToFunc(r);
                        p2 = StringToFunc(p1.unread);
                        return (delegate (double x) {
                            return p1.func(x) * p2.func(x);
                        }, p2.unread);
                    case "/":
                        p1 = StringToFunc(r);
                        p2 = StringToFunc(p1.unread);
                        return (delegate (double x) {
                            return p1.func(x) / p2.func(x);
                        }, p2.unread);
                    case "^":
                        p1 = StringToFunc(r);
                        p2 = StringToFunc(p1.unread);
                        return (delegate (double x) {
                            return Math.Pow(p1.func(x), p2.func(x));
                        }, p2.unread);
                    default:
                        throw (new FormatException());
                }
            }
        }

    }
}
